<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AJAX Simultaneous Requests Test</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <h1>Test AJAX Simultaneous Requests</h1>
    <button id="sendRequests">Send Requests</button>

    <script>
    $(document).ready(function() {
        function sendAjaxRequest(data) {
            return $.ajax({
                url: 'https://api.seospay.tech/api/new/v1/payout/docashtransfer', // Replace with your API endpoint
                type: 'POST',
                headers: {
                    'Authorization':'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiZTlkMTg0OTE2YTIzZTMzMDljZThlMWZiNGE4NzhmNTQ2NGIwOTlkMzQ1YmY5NzNhMzg0YTY1OWQ2ZTkzZjE4N2M5MTVlNzBiMDJiY2UwMDIiLCJpYXQiOjE3MzA5OTkxNTcuMjY3MDMxOTA4MDM1Mjc4MzIwMzEyNSwibmJmIjoxNzMwOTk5MTU3LjI2NzAzNDA1MzgwMjQ5MDIzNDM3NSwiZXhwIjoxNzMxNjAzOTU3LjI2NjUzMjg5Nzk0OTIxODc1LCJzdWIiOiIyIiwic2NvcGVzIjpbXX0.DtsvlVLCD0H8FIGfJkBoMCNHFdf9b6AK9b6Z0OuiaeM9ZteWvxE4qiydkH9slfD7GyfPzaxQqA6iuzXgnNH7OtVcXOoXjH-MCIPM51lOgmATn6Ewj7K-uS2YXk74zUGQkLemLGAagdD19CKDisKYyFp-lT5JQU0SmJcZ_JZ0gtJSRsszrxuCGYiqX_pYdNoSQ-kOw89KGZVny6A1V6MeQNEjlnn8fZU8S4j3aNGQLzax2ZiiP3iDuNfbw-aL9TnU65aJu1tf-w1ZkjZe9VD_YDCc6OabEl5eM26uRSthxJL_AXG1rFEIXkM9-fMSYq6ZegJZ3dI93FUrebY88etXCiGtP-kH-SmFPp7yXWp8UGMyp8YQ3Hxr7SByFFrI0obhp1JsXRak9I4r1xs15qyWbTbMUXns9FyCL0JKYCrUGadkS8LQ1mfQu83aAK-sRqVVXx6_Y2fDbd9UlkokzoizXH0duXhqLcnaTNZ_rzgL9p5ej3rUymLl5mDZ8rct_WhrFU4s5p0w8WUqxq5gepJ7Qt5TF19LRSZg_pmYTjepz2s7g0AI7KpuIRTkIPiLyUcTbvZr-tq5t833TANKwuUcDXq5vhMDM9RnDd_W-SRo8fYg5FPCu-qAIlCL81gXTlGMG8pObSNhOnwVYGKh0daYThh2HjP5aGVz1dx5VB5yC-4',
                     'AuthenticatedKeyId': '99106c21fbe5',  // Replace with actual header values
                    'AuthenticatedToken': 'f1ebf003789c44677ad68cd4debaaa5d2d8dc2a9',
                    'AuthenticatedCode': '876595'
                },
                data: JSON.stringify(data),
                contentType: 'application/json',
                success: function(response) {
                    console.log('Success:', response);
                },
                error: function(xhr, status, error) {
                    console.log('Error:', xhr.responseText);
                }
            });
        }

        $('#sendRequests').click(function() {
            const requests = [
                sendAjaxRequest({
                   
                    name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc1",
    transferAmount:"2",
    transferMode:"IMPS" 
                }),
                sendAjaxRequest({
                    name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc2",
    transferAmount:"2",
    transferMode:"IMPS" 
                }),
                sendAjaxRequest({
                   name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc3",
    transferAmount:"2",
    transferMode:"IMPS" 
                }),
                sendAjaxRequest({
                    name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc4",
    transferAmount:"2",
    transferMode:"IMPS" 
                }),
                sendAjaxRequest({
                    name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc5",
    transferAmount:"5",
    transferMode:"IMPS" 
                }),
                sendAjaxRequest({
                    name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc6",
    transferAmount:"2",
    transferMode:"IMPS" 
                }),
                 sendAjaxRequest({
                    name:"Pawan",
    accountNumber:"1348455828",
    bankIfsc:"KKBK0005047",
    mobileNumber:"9354824675",
    beneBankName:"KK BANK",
    referenceNumber:"mnc7",
    transferAmount:"2",
    transferMode:"IMPS" 
                }),
               
            ];

            // Use Promise.all to ensure all requests are sent at the same time
            Promise.all(requests).then((responses) => {
                console.log('All requests completed', responses);
            }).catch((error) => {
                console.error('An error occurred', error);
            });
        });
    });
    </script>
</body>
</html>
