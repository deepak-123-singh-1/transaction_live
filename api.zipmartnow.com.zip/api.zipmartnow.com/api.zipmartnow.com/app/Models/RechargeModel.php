<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RechargeModel extends Model
{
    use HasFactory;
    protected $table = 'recharge_transactions';

    protected $fillable = [
        'userId',
        'orderId',               
        'txnId',
        'contactId',
        'amount',
        'commission',
        'tds',               
        'totalAmount',
        'operator',
        'mobile',
        'status',
        'IpAddress',
    ];
}