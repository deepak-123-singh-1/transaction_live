<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OtpLog extends Model
{
    use HasFactory;
    protected $table = 'otp_logs';

    protected $fillable = [
        'userId',
        'mobileNumber',               
        'otp',
        'type',
    ];
}
