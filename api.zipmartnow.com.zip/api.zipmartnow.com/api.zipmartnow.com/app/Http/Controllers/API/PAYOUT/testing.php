<?php

namespace App\Http\Controllers\API\PAYOUT;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Carbon;
use App\Models\User;
use App\Models\UserCharge;
use App\Models\UserIp;
use App\Models\UserTransaction;
use App\Models\ApiRequestCount;
use App\Models\PayinModel;
use App\Models\PayoutModel;
use App\Models\ApiLog;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class testing extends Controller

{ 
    
    
    
    public function transferflipfund(Request $request)
    {

        Log::info('Transfer fund request received', [
            'request_data' => $request->all()
        ]);

        $jsonData = $request->json()->all();
        $AuthKey = $request->header('AuthenticatedKeyId');
        $AuthToken = $request->header('AuthenticatedToken');
        $AuthCode = $request->header('AuthenticatedCode');

        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'mobileNumber' => 'required',
            'referenceNumber' => 'required', // |unique:payout_transactions,orderId
            'transferAmount' => 'required|max:49000',
            'transferMode' => 'required',
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed', [
                'errors' => $validator->errors()->toArray(),
            ]);
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => $validator->errors(),
            ];
            return response()->json($responseData, 422);
        }

        $getUser = User::where("user_token", $AuthToken)->where("user_key", $AuthKey)->where("status", 1)->where("api_status", 1)->where("user_type", 1)->where("approved", 1)->first();
        $address = $getUser->city;
        if (empty($getUser)) {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'Invalid credentials',
            ];
            return response()->json($responseData, 401);
        }
        if (Hash::check($AuthCode, $getUser->authCode)) {
        } else {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'Invalid credentials!',
            ];
            return response()->json($responseData, 401);
            die;
        }
        $userId = $getUser->id;
        $api_status = $getUser->api_status;
        if ($api_status == 0) {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'We are taking downtime due to some technical issues. Please wait till further update',
            ];
            return response()->json($responseData, 200);
            die;
        }
        $bank_deactive = $getUser->bank_deactive;
        if ($bank_deactive == 1) {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'Your API has been Deactivated by the Bank due to security reasons.',
            ];
            return response()->json($responseData, 200);
            die;
        }
        $tecnical_issue = $getUser->tecnical_issue;
        if ($tecnical_issue == 1) {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'We are facing technical issue from bank side.',
            ];
            return response()->json($responseData, 200);
            die;
        }

        $ipAddress = $request->ip();
        $checkIp = UserIp::where(['userId' => $userId, 'ipAddress' => $ipAddress])->first();
        if (empty($checkIp)) {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'your ip is not whitlisted, requested ip is ' . $ipAddress,
            ];
            return response()->json($responseData, 401);
            die;
        }

        $referenceNumber = $request['referenceNumber'];
        $merchantId = "ZMRT".rand(123121, 990999) . Carbon::now()->timestamp;
        $name = $request['name'];
        $mobile = $request['mobileNumber'];
        $transferAmount = $request['transferAmount'];
        $transfermode = $request['transferMode'];
        $accountNumber = $request['accountNumber'];
        $ifscCode = $request['bankIfsc'];
        $bankname = $request['beneBankName'];
        // $checkaccountno = $request['reenter_accno'];
        $vpa = $request['vpa'];
        //$transferAmountinpaisa=$transferAmount * 100; 
        $transfer = floatval($transferAmount);
        $transferAmountinpaisa = intval($transfer * 100);

        if ($transfermode == 'IMPS') {
            if ($getUser->IMPS == 1) {
                $validator = Validator::make($request->all(), [
                    'accountNumber' => 'required|string|digits_between:6,20',
                    'bankIfsc' => 'required|string',
                    'beneBankName' => 'required|string',

                ]);
                if ($validator->fails()) {
                    $responseData = [
                        'status' => FALSE,
                        'error' => TRUE,
                        'message' => $validator->errors(),
                    ];
                    return response()->json($responseData, 422);
                }
                $fields = [
                    "name" => $name,
                    "email" => "info.zipmartnow@gmail.com",
                    "mobile_number" => $mobile,
                    "address" => $address,
                    "payment_type" => 3,
                    // "bank_name" => $bankname,
                    "account_number" => $accountNumber,
                    "amount" => $transferAmountinpaisa,
                    "merchant_order_id" => $merchantId,
                    "ifsc_code" => $ifscCode
                ];
            } else {
                $responseData = [
                    'status' => FALSE,
                    'error' => TRUE,
                    'message' => 'IMPS not permitted',
                ];
                return response()->json($responseData, 200);
                die;
            }
        } elseif ($transfermode == 'UPI') {
            if ($getUser->UPI == 1) {

                $validator = Validator::make($request->all(), [
                    'vpa' => 'required|string',
                ]);

                if ($validator->fails()) {
                    $responseData = [
                        'status' => FALSE,
                        'error' => TRUE,
                        'message' => $validator->errors(),
                    ];
                    return response()->json($responseData, 422);
                }
                $fields = [
                    "name" => $name,
                    "email" => "info.zipmartnow@gmail.com",
                    "mobile_number" => $mobile,
                    "address" => $address,
                    "payment_method" => 2,
                    "account_number" =>  $vpa,
                    "amount" => $transferAmountinpaisa,
                    "merchant_order_id" => $merchantId,
                    "ifsc" => " "
                ];
            } else {
                $responseData = [
                    'status' => FALSE,
                    'error' => TRUE,
                    'message' => 'UPI not permitted',
                ];
                return response()->json($responseData, 200);
                die;
            }
        } else {
            $responseData = [
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'Invalid transfer mode',
            ];
            return response()->json($responseData, 200);
            die;
        }

        DB::beginTransaction();
        try {
            // $getUser = DB::table('users')->where('id', $getUser->id)->lockForUpdate()->first();
            $getUser = \App\Models\User::where('id', $getUser->id)->lockForUpdate()->first();
            $getCommission = UserCharge::where('start_amount', '<=', $transferAmount)->where('end_amount', '>=', $transferAmount)->where('userId', '=', $userId)->first();
            if (empty($getCommission)) {
                $charge = 20;
                $chargeType = "F";
            } else {
                $charge = $getCommission->payout_charge;
                $chargeType = $getCommission->payout_charge_type;
            }
            $gst = 18;
            if ($chargeType == "F") {
                $totalCharge = $charge;
                $totalGst = ($totalCharge * $gst) / 100;
            } else if ($chargeType == "P") {
                $totalCharge = ($transferAmount * $charge) / 100;
                $totalGst = ($totalCharge * $gst) / 100;
            }
            $totalDeductAmount = $transferAmount + $totalCharge + $totalGst;
            $openBal = $getUser->wallet;
            $lien = $getUser->lien;
            $rolling_reserve = $getUser->rolling_reserve;
            $closeBal = $openBal - $totalDeductAmount;
            $checkAmount = $totalDeductAmount + $lien + $rolling_reserve;

            if ($openBal == 0 || $openBal < $checkAmount) {
                DB::rollBack();
                $responseData = [
                    'status' => FALSE,
                    'error' => TRUE,
                    'message' => 'Insufficient fund',
                ];
                return response()->json($responseData, 200);
                die;
            }
            // -----------------------------------------------------------------
            // $UserInstance = new User();
            // $UserInstance->deductFund($userId,$totalDeductAmount);

            $getUser->update(['wallet' => DB::raw("wallet - $totalDeductAmount")]);

            $remark = "Money Transfer Via Payout ";
            UserTransaction::create([
                'userId' => $userId,
                'txnId' => $merchantId,
                'orderId' => $referenceNumber,
                'type' => "DEBIT",
                'operator' => "PAYOUT",
                'openBalance' => $openBal,
                'amount' => $totalDeductAmount,
                'walletBalance' => $closeBal,
                'credit' => 0,
                'debit' => $totalDeductAmount,
                "status" => "PROCESSING", // PENDING
                'remark' => $remark,
                'api' => "FLIPZIK_M",
                'requestIp' => $ipAddress,
                'created_by' => $userId,
            ]);

            PayoutModel::create([
                'userId' => $userId,
                'txnId' => $merchantId,
                'orderId' => $referenceNumber,
                'amount' => $transferAmount,
                'charge' => $totalCharge,
                'gst' => $totalGst,
                'totalAmount' => $totalDeductAmount,
                'mode' => $transfermode,
                'beneName' => $name,
                'beneBank' => $bankname,
                'beneAccount' => $accountNumber,
                'beneIfsc' => $ifscCode,
                'status' => "PROCESSING", // PENDING
                'api' => "FLIPZIK_M",
                'IpAddress' => $ipAddress,
                'mobile' => $mobile,
                'contactId' => $vpa,
            ]);

            DB::commit();
            // $amountcheck = intval($transferAmount);

            // if ($amountcheck % 1000 == 0 && ($ifscCode == "IPOS0000001" || $ifscCode == "AIRP0000001")) {

            //     $updateUser = [
            //         'status' => "FAILED"
            //     ];

            //     $UserTransaction = new UserTransaction();
            //     $UserTransaction->updateUserTxnData($updateUser, $merchantId);

            //     $updatePayout = [
            //         "status" => "FAILED",
            //         "remark" => "FAILED"
            //     ];
            //     $PayoutModel = new PayoutModel();
            //     $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //     $responseData = [
            //         "status" => "FAILED",
            //         "message" => "Transaction is Failed",
            //         "data" => array(
            //             "payout_ref" => $referenceNumber,
            //             "txn_id" => $merchantId,
            //             "bank_ref" => ""
            //         ),
            //     ];
            //     DB::commit();
            //     return response()->json($responseData, 200);
            //     die;
            // }

            // $button_1 = $getUser->button_1;
            // if ($button_1 == 1) {
            //     $updatePayout = [
            //         "button" => "pending1",
            //     ];
            //     $PayoutModel = new PayoutModel();
            //     $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //     $responseData = [
            //         "status" => "Pending",
            //         "message" => "Transaction is Pending",
            //         "data" => array(
            //             "payout_ref" => $referenceNumber,
            //             "txn_id" => $merchantId,
            //             "bank_ref" => ""
            //         ),
            //     ];
            //     DB::commit();
            //     return response()->json($responseData, 200);
            //     die;
            // }

            // $button_2 = $getUser->button_2;
            // if ($button_2 == 1) {
            //     $apiRequestCount = DB::table('api_request_count')->where('user_id', $userId)->first();
            //     if (!$apiRequestCount) {
            //         DB::table('api_request_count')->insert([
            //             'user_id' => $userId,
            //             'request_count' => 1
            //         ]);
            //         $currentCount = 1;
            //     } else {
            //         $currentCount = $apiRequestCount->request_count + 1;
            //         $updateResult = DB::table('api_request_count')->where('user_id', $userId)->update(['request_count' => $currentCount]);
            //     }
            //     if ($currentCount % 4 === 0) {
            //         DB::table('api_request_count')->where('user_id', $userId)->update(['request_count' => 0]);
            //         $updatePayout = [
            //             "button" => "pending2",
            //         ];
            //         $PayoutModel = new PayoutModel();
            //         $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //         $responseData = [
            //             "status" => "Pending",
            //             "message" => "Transaction is Pending",
            //             "data" => array(
            //                 "payout_ref" => $referenceNumber,
            //                 "txn_id" => $merchantId,
            //                 "bank_ref" => ""
            //             ),
            //         ];
            //         DB::commit();
            //         return response()->json($responseData, 200);
            //         die;
            //     }
            // }

            // $button3_value = $getUser->button3_value;
            // $button_3 = $getUser->button_3;
            // if ($button_3 == 1) {
            //     $pendingRequestsLimit = 2;
            //     $processedRequestsLimit = $button3_value + $pendingRequestsLimit;

            //     $apiRequestCount = DB::table('api_request_count')->where('user_id', $userId)->first();
            //     if (!$apiRequestCount) {
            //         DB::table('api_request_count')->insert([
            //             'user_id' => $userId,
            //             'request_count' => 1
            //         ]);
            //         $currentCount = 1;
            //     } else {
            //         $currentCount = $apiRequestCount->request_count + 1;
            //         DB::table('api_request_count')->where('user_id', $userId)->update(['request_count' => $currentCount]);
            //     }
            //     $requestsInCycle = $currentCount % $processedRequestsLimit;

            //     if ($requestsInCycle >= $button3_value) {
            //         if ($requestsInCycle == $processedRequestsLimit - 1) {
            //             DB::table('api_request_count')->where('user_id', $userId)->update(['request_count' => 0]);
            //         }
            //         $updatePayout = [
            //             "button" => "pending3",
            //         ];

            //         $PayoutModel = new PayoutModel();
            //         $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //         $responseData = [
            //             "status" => "Pending",
            //             "message" => "Transaction is Pending",
            //             "data" => array(
            //                 "payout_ref" => $referenceNumber,
            //                 "txn_id" => $merchantId,
            //                 "bank_ref" => ""
            //             ),
            //         ];
            //         DB::commit();
            //         return response()->json($responseData, 200);
            //         die;
            //     }
            // }

            // $access_key = "c6e82097aa424e17e7619c9b0110c411";
            // $secret = "91904136d54ebd330dbb39e0be753233";

            // function calculate_hmac($secret, $timestamp, $body, $path, $query_string = '', $method = 'GET')
            // {
            //     $message = $method . "\n" . $path . "\n" . $query_string . "\n" . $body . "\n" . $timestamp . "\n";
            //     return hash_hmac('sha512', $message, $secret);
            // }

            // $url = "https://api.flipzik.com";
            // $path = "/api/v1/payout/process";
            // $recorddata = json_encode($fields);
            // $x_timestamp  = floor(microtime(true) * 1000);
            // $signature = calculate_hmac($secret, $x_timestamp, $recorddata, $path, '', 'POST');

            // $header_data = array(
            //     "Content-Type: application/json",
            //     "User-Agent: team testing",
            //     "access_key:" . $access_key,
            //     "signature:" . $signature,
            //     "X-Timestamp:" . $x_timestamp,
            // );

            // $ch = curl_init();
            // curl_setopt_array($ch, array(
            //     CURLOPT_URL => $url . $path,
            //     CURLOPT_RETURNTRANSFER => true,
            //     CURLOPT_ENCODING => '',
            //     CURLOPT_MAXREDIRS => 10,
            //     CURLOPT_TIMEOUT => 0,
            //     CURLOPT_FOLLOWLOCATION => true,
            //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            //     CURLOPT_CUSTOMREQUEST => 'POST',
            //     CURLOPT_POSTFIELDS => $recorddata,
            //     CURLOPT_HTTPHEADER => $header_data,
            //     CURLOPT_HEADER => true, // Include headers in response
            // ));

            // $response = curl_exec($ch);
            // Log::info('cURL Response: ' . $response);
            // if ($response === false) {
            //     echo "cURL Error: " . curl_error($ch);
            //     curl_close($ch);
            //     exit;
            // }

            // // Separate headers and body
            // $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            // $header = substr($response, 0, $header_size);
            // $body = substr($response, $header_size);
            // curl_close($ch);

            // ApiLog::create([
            //     'txnId' => $merchantId,
            //     'request' => $recorddata,
            //     'response' => $response,
            //     'service' => "PAYOUT",
            //     'service_api' => "FLIPZIK",
            // ]);
            // DB::commit();

            // if (preg_match('/Content-Type:\s*application\/json/i', $header)) {

            //     $responseData = json_decode($body, true);
            //     $data = isset($responseData['data']) ? $responseData['data'] : '';
            //     $status = isset($data['status']) ? $data['status'] : '';
            //     $clientgatewayid = isset($data['id']) ? $data['id'] : '';
            //     $clientutr = isset($data['bank_reference_id']) ? $data['bank_reference_id'] : '';

            //     if ($status == "Failed" || $status == "Reversed" || $status == "Rejected") {
            //         $updateUser = [
            //             'status' => "FAILED"
            //         ];

            //         $UserTransaction = new UserTransaction();
            //         $UserTransaction->updateUserTxnData($updateUser, $merchantId);

            //         $updatePayout = [
            //             "payoutId" => $clientgatewayid,
            //             "utr" => $clientutr,
            //             "status" => "FAILED",
            //         ];
            //         $PayoutModel = new PayoutModel();
            //         $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //         //$user = User::findOrFail($userId);
            //         $UserInstance = new User();
            //         $UserInstance->addFund($userId, $totalDeductAmount);

            //         $responseData = [
            //             "status" => "FAILED",
            //             "message" => "Transaction is Failed",
            //             "data" => array(
            //                 "payout_ref" => $referenceNumber,
            //                 "txn_id" => $merchantId,
            //                 "bank_ref" => $clientutr,
            //             ),
            //         ];
            //         DB::commit();
            //         return response()->json($responseData, 200);
            //     }

            //     if ($status == "Success") {
            //         $updateUser = [
            //             'status' => "SUCCESS"
            //         ];

            //         $UserTransaction = new UserTransaction();
            //         $UserTransaction->updateUserTxnData($updateUser, $merchantId);

            //         $updatePayout = [
            //             "utr" => $clientutr,
            //             "payoutId" => $clientgatewayid,
            //             "status" => "SUCCESS",
            //             // "remark"=>$statusMessage
            //         ];
            //         $PayoutModel = new PayoutModel();
            //         $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //         $responseData = [
            //             "status" => "SUCCESS",
            //             "message" => "Transaction is Successful",
            //             "data" => array(
            //                 "payout_ref" => $referenceNumber,
            //                 "txn_id" => $merchantId,
            //                 "bank_ref" => $clientutr
            //             ),
            //         ];
            //         DB::commit();
            //         return response()->json($responseData, 200);
            //     }

            //     if ($status == "Pending" || $status == "Initiated") {
            //         $updatePayout = [
            //             "payoutId" => $clientgatewayid,
            //         ];
            //         $PayoutModel = new PayoutModel();
            //         $PayoutModel->updatePayoutData($updatePayout, $merchantId);

            //         $responseData = [
            //             "status" => "Pending",
            //             "message" => "Transaction is Pending",
            //             "data" => array(
            //                 "payout_ref" => $referenceNumber,
            //                 "txn_id" => $merchantId,
            //                 "bank_ref" => ""
            //             ),
            //         ];
            //         DB::commit();
            //         return response()->json($responseData, 200);
            //     }
            // } else {
                
            //     return response()->json([
            //         'status' => FALSE,
            //         'error' => TRUE,
            //         'message' => $body,
            //         // 'exceptionMessage' => $e->getMessage(),
            //     ], 500);
            // }
        } catch (\Exception $e) {

            Log::error('Transaction rollback', [
                'userId' => $getUser->id ?? null,
                'requestData' => $request->all(),
                'exceptionMessage' => $e->getMessage(),
                'exceptionTrace' => $e->getTraceAsString(),
                'timestamp' => now(),
            ]);
            DB::commit();
            return response()->json([
                'status' => FALSE,
                'error' => TRUE,
                'message' => 'Transaction failed. Please try again.',
                // 'exceptionMessage' => $e->getMessage(),
            ], 500);
        }
    }
    
    



    public function checkStatusnew(Request $request){

        $jsonData = $request->json()->all();        
        $Authorization = $request->header('Authorization');

        $validator = Validator::make($request->all(), [
            'referenceNumber' => 'required',            
        ]);

        if($validator->fails()) {
            $responseData = [                
                'status' => FALSE,
                'error'=> TRUE,
                'message' => $validator->errors(),
            ];
            return response()->json($responseData, 422); die;
        }

        $getUser = User::where("user_token",$Authorization)->where("status",1)->where("api_status",1)->where("user_type",1)->first();
        if(empty($getUser)){
            $responseData = [                
                'status' => FALSE,
                'error'=> TRUE,
                'message' => 'Invalid credentials.',
            ];
            return response()->json($responseData , 401); die;
        }

        $userId = $getUser->id;
        $referenceNumber = $request['referenceNumber'];
        
  
        $checkTxn = PayoutModel::where("orderId",$referenceNumber)->where("userId",$userId)->where("api","FLIPZIK")->get()->toArray();
     
        if(empty($checkTxn)){
            $responseData = [                
                'status' => FALSE,
                'error'=> TRUE,
                'message' => 'Transaction not found.',
            ];
            return response()->json($responseData , 200); die;
        }
        
        $status = $checkTxn[0]['status'];
        $merchantId = $checkTxn[0]['txnId'];
        $utr= $checkTxn[0]['utr'];
        
          if($status == "FAILED"){
              
           $responseData = [
                "status" => "Failed",
                 "message" => "Transaction is Failed",
                "data" => array(
                  "payout_ref" => $referenceNumber,
                    "txn_id" => $merchantId,
                    "bank_ref" => ""
                ),
            ];
           
            return response()->json($responseData, 200);}

        if($status == "SUCCESS") {
          $responseData = [
                "status" => "Success",
                 "message" => "Transaction is Success",
                "data" => array(
                  "payout_ref" => $referenceNumber,
                    "txn_id" => $merchantId,
                    "bank_ref" => $utr
                ),
            ];
           
            return response()->json($responseData, 200);
    }
    
    if($status == "PENDING") {
        
           $responseData = [
                "status" => "Pending",
                 "message" => "Transaction is Pending",
                "data" => array(
                  "payout_ref" => $referenceNumber,
                    "txn_id" => $merchantId,
                    "bank_ref" => ""
                ),
            ];
           
            return response()->json($responseData, 200);
         
    }
}  
    public function callbackurlpending() {
   
        $userTransactions = PayoutModel::where('userId', 2)
            ->whereIn('button', ['pending1', 'pending2', 'pending3'])
            ->get();
    
        if ($userTransactions->isEmpty()) {
            Log::info("No pending transactions found for user ID 2 with required button status.");
            return;
        }
    
       
        foreach ($userTransactions as $userTransaction) {
            $amount = $userTransaction->amount;
            $merchantId = $userTransaction->orderId;
            $orderid = $userTransaction->txnId;
            $status = $userTransaction->status;
    
           
            $responseData = [
                "amount" => $amount,
                "merchant_order_id" => $merchantId,
                "Reference_id" => $orderid,
                "status" => $status,
                "utr" => "",
            ];
    
            $finalResponse = [
                "data" => $responseData,
            ];
    
            $userId = $userTransaction->userId;
            $user = User::find($userId);
    
            if ($user && $user->payout_callback) {
                $userURL = "https://api.seospay.tech/api/rcvcallback";
    
                try {
                    $response = Http::post($userURL, $finalResponse);
    
                    if ($response->successful()) {
                        
                        $userTransaction->button .= ' sentcallback';
                        $userTransaction->save();
                    }
                } catch (\Exception $e) {
                    Log::error("Callback failed for transaction ID {$userTransaction->id}: " . $e->getMessage());
                }
            } else {
                Log::info("No callback URL found for user ID {$userId}.");
            }
        }
    }


}