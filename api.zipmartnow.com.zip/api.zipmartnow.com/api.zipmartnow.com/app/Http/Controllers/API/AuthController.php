<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class AuthController extends Controller
{
    public function registerUser(Request $request)
    {

        echo \Hash::make($request->password);die;
        $user = User::create([
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>\Hash::make($request->password),
        ]);

        $token = $user->createToken('Token')->accessToken;
       // return response()->json(["token"=>$token,"userDate"=>$user],200);
    }

    public function login(Request $request)
    {
        $data = [
            'mobile'=>$request->mobile,
            'password'=>$request->password,
        ];

        if(auth()->attempt($data)){
            $token = auth()->user()->createToken('Token')->accessToken;
            return response()->json(["token"=>$token],200);
        }
        //return response()->json(["error"=>"Unauthorized"],401);
    }

    public function profile(){

        $user = auth()->user();
        //return response()->json(["user"=>$user],200);
    }
    
    public function rateLimitCheck(){
        return response()->json([
            "message"=>"Check retlimit here."
        ],200);
    }
    
    
    
}
