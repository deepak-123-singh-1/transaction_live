-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2025 at 01:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dashboardseospay_seospaydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `api_logs`
--

CREATE TABLE `api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `txnId` varchar(255) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `response` text DEFAULT NULL,
  `callback` text DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `service_api` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `api_request_count`
--

CREATE TABLE `api_request_count` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `request_count` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `beneName` varchar(255) DEFAULT NULL,
  `beneAccount` varchar(255) DEFAULT NULL,
  `beneIfsc` varchar(255) DEFAULT NULL,
  `pancard` varchar(255) DEFAULT NULL,
  `addhaarFront` varchar(255) DEFAULT NULL,
  `addhaarBank` varchar(255) DEFAULT NULL,
  `cancelCheque` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bank_accounts`
--

INSERT INTO `bank_accounts` (`id`, `userId`, `beneName`, `beneAccount`, `beneIfsc`, `pancard`, `addhaarFront`, `addhaarBank`, `cancelCheque`, `status`, `created_at`, `updated_at`) VALUES
(18, 2, 'lovely', '768', 'okk', 'PAN1727435361.PNG', 'aaf1727435361.PNG', 'aab1727435361.PNG', 'cccs1727435361.PNG', 1, '2024-09-27 11:09:21', '2024-09-27 11:37:21'),
(19, 56, 'SHREE REALTORS', '60730200000012', 'BARB0BAVDHA', 'PAN1728115347.jpeg', 'aaf1728115347.jpeg', 'aab1728115347.jpeg', 'cccs1728115347.pdf', 1, '2024-10-05 08:02:27', '2024-10-05 08:03:21'),
(20, 56, 'BEENOO SING', '43730200000150', 'BARB0ZAFRAB', 'PAN1728116982.jpeg', 'aaf1728116982.jpeg', 'aab1728116982.jpeg', 'cccs1728116982.pdf', 1, '2024-10-05 08:29:42', '2024-10-05 08:31:35'),
(21, 56, 'SAIBABA ELECTRONICS AND MOBIL', '43670200000688', 'BARB0RANIDU', 'PAN1728117876.jpeg', 'aaf1728117876.jpeg', 'aab1728117876.jpeg', 'cccs1728117876.jpeg', 0, '2024-10-05 08:44:36', '2024-10-05 08:44:36'),
(22, 56, 'BALAJI PROPERTY BROKER', '38940200000351', 'BARB0BADNAW', 'PAN1728118082.jpeg', 'aaf1728118082.jpeg', 'aab1728118082.jpeg', 'cccs1728118082.jpeg', 0, '2024-10-05 08:48:02', '2024-10-05 08:48:02');

-- --------------------------------------------------------

--
-- Table structure for table `dmt_transaction`
--

CREATE TABLE `dmt_transaction` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `orderId` varchar(255) DEFAULT NULL,
  `txnId` varchar(255) DEFAULT NULL,
  `contactId` varchar(255) DEFAULT NULL,
  `amount` double(14,3) DEFAULT 0.000,
  `charge` double(10,3) NOT NULL DEFAULT 0.000,
  `totalAmount` double(14,3) NOT NULL DEFAULT 0.000,
  `beneName` varchar(255) DEFAULT NULL,
  `beneBank` varchar(255) DEFAULT NULL,
  `beneAccount` varchar(255) DEFAULT NULL,
  `beneIfsc` varchar(255) DEFAULT NULL,
  `utr` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'PENDING',
  `createDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updateDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `mobileNumber` varchar(50) NOT NULL,
  `otp` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `ipAddress` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `unique_id` int(11) NOT NULL,
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp_logs`
--

CREATE TABLE `otp_logs` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `mobileNumber` varchar(50) NOT NULL,
  `otp` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payin_transactions`
--

CREATE TABLE `payin_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `orderId` varchar(255) DEFAULT NULL,
  `txnId` varchar(255) DEFAULT NULL,
  `upiTxnId` varchar(255) DEFAULT NULL,
  `upiId` varchar(255) DEFAULT NULL,
  `contactId` varchar(255) DEFAULT NULL,
  `amount` double(14,4) NOT NULL DEFAULT 0.0000,
  `charge` double(14,4) NOT NULL DEFAULT 0.0000,
  `gst` double(14,4) NOT NULL DEFAULT 0.0000,
  `totalAmount` double(14,4) NOT NULL DEFAULT 0.0000,
  `payerName` varchar(255) DEFAULT NULL,
  `payerMobile` varchar(255) DEFAULT NULL,
  `payerVa` varchar(255) DEFAULT NULL,
  `utr` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `IpAddress` varchar(255) DEFAULT NULL,
  `txn_time` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payout_transactions`
--

CREATE TABLE `payout_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `orderId` varchar(255) DEFAULT NULL,
  `txnId` varchar(255) DEFAULT NULL,
  `referenceId` varchar(255) DEFAULT NULL,
  `payoutId` varchar(255) DEFAULT NULL,
  `contactId` varchar(255) DEFAULT NULL,
  `amount` double(14,4) DEFAULT 0.0000,
  `charge` double(14,4) NOT NULL DEFAULT 0.0000,
  `gst` double(14,4) NOT NULL DEFAULT 0.0000,
  `totalAmount` double(14,4) NOT NULL DEFAULT 0.0000,
  `mode` varchar(255) DEFAULT NULL,
  `beneName` varchar(255) DEFAULT NULL,
  `beneBank` varchar(255) DEFAULT NULL,
  `beneAccount` varchar(255) DEFAULT NULL,
  `beneIfsc` varchar(255) DEFAULT NULL,
  `utr` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `api` varchar(300) DEFAULT NULL,
  `remark` varchar(300) DEFAULT NULL,
  `IpAddress` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `platform_charges`
--

CREATE TABLE `platform_charges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `charge` double(14,4) NOT NULL DEFAULT 0.0000,
  `gst` double(14,4) NOT NULL DEFAULT 0.0000,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recharge_commission`
--

CREATE TABLE `recharge_commission` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `opcode` varchar(255) DEFAULT NULL,
  `commission` double(14,4) NOT NULL DEFAULT 0.0000,
  `type` varchar(10) NOT NULL DEFAULT 'P',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recharge_transactions`
--

CREATE TABLE `recharge_transactions` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `orderId` varchar(255) NOT NULL,
  `txnId` varchar(255) NOT NULL,
  `contactId` varchar(255) DEFAULT NULL,
  `amount` double(14,4) NOT NULL DEFAULT 0.0000,
  `commission` double(14,4) NOT NULL DEFAULT 0.0000,
  `tds` double(14,4) NOT NULL DEFAULT 0.0000,
  `totalAmount` double(14,4) NOT NULL DEFAULT 0.0000,
  `mobile` varchar(255) NOT NULL,
  `operator` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'PENDING',
  `IpAddress` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `wallet` double(14,4) NOT NULL DEFAULT 0.0000,
  `lien` double(14,4) NOT NULL DEFAULT 0.0000,
  `rolling_reserve` double(14,4) NOT NULL DEFAULT 0.0000,
  `user_key` varchar(255) DEFAULT NULL,
  `user_token` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `aadhaar_card` varchar(255) NOT NULL,
  `pancard` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `api_status` tinyint(4) NOT NULL DEFAULT 0,
  `tecnical_issue` int(11) NOT NULL DEFAULT 0,
  `vouch` int(11) NOT NULL DEFAULT 0,
  `DMV` varchar(100) DEFAULT NULL,
  `haoda` varchar(100) DEFAULT NULL,
  `IMPS` varchar(45) DEFAULT '0',
  `UPI` varchar(45) DEFAULT '0',
  `bank_deactive` int(11) NOT NULL DEFAULT 0,
  `user_type` tinyint(4) NOT NULL DEFAULT 0,
  `agent_id` int(11) NOT NULL DEFAULT 0,
  `payin_callback` varchar(500) DEFAULT NULL,
  `payout_callback` varchar(500) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `lpin` varchar(255) DEFAULT NULL,
  `mpin` varchar(255) DEFAULT NULL,
  `approved` int(11) NOT NULL DEFAULT 0,
  `authCode` varchar(255) DEFAULT NULL,
  `button_1` int(11) NOT NULL DEFAULT 0,
  `button_2` int(11) NOT NULL DEFAULT 0,
  `button_3` int(11) NOT NULL DEFAULT 0,
  `button3_value` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `secretid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `wallet`, `lien`, `rolling_reserve`, `user_key`, `user_token`, `mobile`, `email`, `company_name`, `aadhaar_card`, `pancard`, `address`, `city`, `state`, `pincode`, `status`, `api_status`, `tecnical_issue`, `vouch`, `DMV`, `haoda`, `IMPS`, `UPI`, `bank_deactive`, `user_type`, `agent_id`, `payin_callback`, `payout_callback`, `created_by`, `updated_by`, `remember_token`, `lpin`, `mpin`, `approved`, `authCode`, `button_1`, `button_2`, `button_3`, `button3_value`, `created_at`, `updated_at`, `secretid`) VALUES
(1, 'Seospay', '$2y$10$2WERqwxp0V5moQdW/pxIYOv9Hc3JNAJjRtAjI4N5XRduAooeGfqLK', 0.0000, 0.0000, 0.0000, 'f9c1ac6a4157', '51246acfbe14eb1c4f575ba55c28b11cb4535d3b', '7366857413', 'abhishekchanchal133@gmail.com', 'Seospay', '980890890987', 'AAAAA1111A', 'D block noida', 'noida', 'UP', '201301', 1, 1, 0, 0, '0', '0', NULL, NULL, 0, 0, 0, NULL, NULL, 0, 0, NULL, '$2y$10$Qg5tGAud6ti.FIS2iNmlFeHCPS5o.7LuBEgOmLsbSjKgPBaJbeaO6', '$2y$10$UeIBzYkM.Jr7yKd.CXaPuu0tdzIGMtGZJU0mw0BSzGVGgTHVdOgtK', 0, '', 0, 0, 0, 0, '2023-08-21 01:36:32', '2024-06-06 11:22:24', NULL),
(31, 'Sub Admin', '$2y$10$Vv1G6LZrbiwYkyy1AaAOx.aUcCkxZkKoXqKOPtx4o3NWPxX/D511.', 0.0000, 0.0000, 0.0000, '', '', '8855221133', 'subadmin@seospay.in', 'SEOSPAY', '618937549588', 'CUNPD6944L', 'Noida sector 63', 'Noida', 'UP', '201301', 1, 0, 0, 0, '0', '0', NULL, NULL, 0, 4, 0, NULL, NULL, 1, 0, NULL, NULL, '$2y$10$3kB7Yp6HhiyhwBrry0PITuBs7cIu6UIMPhVHZ3oSW.tqnK.4fzCwa', 0, NULL, 0, 0, 0, 0, '2024-02-08 04:16:11', '2024-05-15 11:57:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_charges`
--

CREATE TABLE `user_charges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `start_amount` double(14,4) NOT NULL DEFAULT 0.0000,
  `end_amount` double(14,4) NOT NULL DEFAULT 0.0000,
  `payout_charge` double(14,4) NOT NULL DEFAULT 0.0000,
  `payin_charge` double(14,4) NOT NULL DEFAULT 0.0000,
  `payin_charge_type` text DEFAULT NULL,
  `payout_charge_type` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_ips`
--

CREATE TABLE `user_ips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `ipAddress` varchar(500) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_transactions`
--

CREATE TABLE `user_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `txnId` varchar(255) DEFAULT NULL,
  `orderId` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `operator` varchar(50) DEFAULT NULL,
  `openBalance` decimal(14,3) NOT NULL DEFAULT 0.000,
  `amount` double(14,4) NOT NULL DEFAULT 0.0000,
  `walletBalance` double(14,4) NOT NULL DEFAULT 0.0000,
  `credit` double(14,3) NOT NULL DEFAULT 0.000,
  `debit` double(14,3) NOT NULL DEFAULT 0.000,
  `remark` varchar(255) DEFAULT NULL,
  `requestIp` varchar(255) DEFAULT NULL,
  `api` varchar(255) DEFAULT NULL,
  `refundId` varchar(300) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wallet_topups`
--

CREATE TABLE `wallet_topups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `bankname` text DEFAULT NULL,
  `amount` double(14,4) NOT NULL DEFAULT 0.0000,
  `paymentslip` varchar(255) DEFAULT NULL,
  `charge` double(14,4) NOT NULL DEFAULT 0.0000,
  `gst` double(14,4) NOT NULL DEFAULT 0.0000,
  `totalAmount` double(14,4) NOT NULL DEFAULT 0.0000,
  `utr` varchar(255) DEFAULT NULL,
  `requestedBy` varchar(255) DEFAULT NULL,
  `requestedRemark` varchar(255) DEFAULT NULL,
  `approvedBy` varchar(255) DEFAULT NULL,
  `approvedRemark` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_logs`
--
ALTER TABLE `api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `txnId` (`txnId`);

--
-- Indexes for table `api_request_count`
--
ALTER TABLE `api_request_count`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dmt_transaction`
--
ALTER TABLE `dmt_transaction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `txnId` (`txnId`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`unique_id`);

--
-- Indexes for table `otp_logs`
--
ALTER TABLE `otp_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payin_transactions`
--
ALTER TABLE `payin_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payout_transactions`
--
ALTER TABLE `payout_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`orderId`),
  ADD KEY `userId_2` (`userId`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `txnId` (`txnId`),
  ADD KEY `amount` (`amount`),
  ADD KEY `totalAmount` (`totalAmount`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `platform_charges`
--
ALTER TABLE `platform_charges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `recharge_commission`
--
ALTER TABLE `recharge_commission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recharge_transactions`
--
ALTER TABLE `recharge_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_mobile_unique` (`mobile`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_aadhaar_card_unique` (`aadhaar_card`),
  ADD UNIQUE KEY `users_pancard_unique` (`pancard`),
  ADD KEY `user_token` (`user_token`);

--
-- Indexes for table `user_charges`
--
ALTER TABLE `user_charges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`start_amount`,`end_amount`),
  ADD KEY `userId_2` (`userId`);

--
-- Indexes for table `user_ips`
--
ALTER TABLE `user_ips`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `userId_2` (`userId`,`ipAddress`);

--
-- Indexes for table `user_transactions`
--
ALTER TABLE `user_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`txnId`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `status` (`status`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `updated_at` (`updated_at`),
  ADD KEY `type` (`type`),
  ADD KEY `operator` (`operator`);

--
-- Indexes for table `wallet_topups`
--
ALTER TABLE `wallet_topups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `totalAmount` (`totalAmount`),
  ADD KEY `utr` (`utr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_logs`
--
ALTER TABLE `api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `api_request_count`
--
ALTER TABLE `api_request_count`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `dmt_transaction`
--
ALTER TABLE `dmt_transaction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29328;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  MODIFY `unique_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otp_logs`
--
ALTER TABLE `otp_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payin_transactions`
--
ALTER TABLE `payin_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payout_transactions`
--
ALTER TABLE `payout_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `platform_charges`
--
ALTER TABLE `platform_charges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recharge_commission`
--
ALTER TABLE `recharge_commission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recharge_transactions`
--
ALTER TABLE `recharge_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `user_charges`
--
ALTER TABLE `user_charges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_ips`
--
ALTER TABLE `user_ips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_transactions`
--
ALTER TABLE `user_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wallet_topups`
--
ALTER TABLE `wallet_topups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
