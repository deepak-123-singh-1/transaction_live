@include('user/header')
<!-- Page Container START -->
<div class="page-container">
<!-- Content Wrapper START -->
<div class="main-content">    
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Check User Balance Api</h5>                                        
                    </div>
                    <div class="m-t-30">
                        <div class="table-responsive-md table-responsive-sm">
                            <table class="table table-hover table-bordered" id="datatable"> 
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <th>https://api.zipmartnow.com/api/new/user-check-balance</th>
                                    </tr>
                                    <tr>
                                        <th>Method</th>
                                        <th>POST</th>
                                    </tr>
                                    <tr>
                                        <th>Header</th>
                                        <th>Pass : Authorization Key <a target="_blank" href="/user/dev-setting">click</a> Like : Authorization:yourkey</th>
                                        <th>Pass : Auth token </th>
                                        <th>Pass : Bearer your authorization token </th>
                                    </tr>
                                     <tr>
                                        <th>REQUEST</th>
                                        <th>
                                            {
                                                "email": "V******ma",
                                                "password": "1********2"
                                            }
                                        </th>
                                    </tr>
                                    <tr>
                                    <tr>
                                        <th>Response</th>
                                        <th>{
                                                "name": "a*****c",
                                                "balance":456,
                                            }
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Payout Api</h5>                                        
                    </div>
                    <div class="m-t-30">
                        <div class="table-responsive-md table-responsive-sm">
                            <table class="table table-hover table-bordered" id="datatable"> 
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <th>https://api.zipmartnow.com/api/new/v1/payout/docashtransfer</th>
                                    </tr>
                                    <tr>
                                        <th>Method</th>
                                        <th>POST</th>
                                    </tr>
                                    <tr>
                                        <th>Header</th>
                                        <th>Pass : Authorization Key <a target="_blank" href="/user/dev-setting">click</a> Like : Authorization:yourkey</th>
                                        <th>Pass : Auth token </th>
                                        <th>Pass : Auth Code </th>
                                        <th>Pass : Bearer your authorization token </th>
                                    </tr>
                                    <tr>
                                        <th>REQUEST FOR IMPS</th>
                                        <th>
                                            {
                                                "name": "V******ma",
                                                "accountNumber": "1********2",
                                                "bankIfsc": "K********6",
                                                "mobileNumber": "9********8",
                                                "beneBankName": "K********K",
                                                "referenceNumber": "3***********9",
                                                "transferAmount": "100",
                                                "transferMode": "IMPS"
                                            }
                                        </th>
                                    </tr>
                                      <tr>
                                        <th>REQUEST FOR UPI</th>
                                        <th>
                                            {  "name": "lo****ly",
                                               "accountNumber": "9****5@ybl",  
                                               "mobileNumber": "9***10",
                                               "referenceNumber": "43****0",
                                               "transferAmount": "1",
                                               "transferMode": "UPI"
                                            }
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Response</th>
                                        <th>{
                                                "status": "SUCCESS",
                                                "message": "Transaction is Successful.",
                                                "data": {
                                                    "payout_ref": "311541447890789","TxnId":"SEOS182***85,
                                                    "bank_ref": "325415029910"
                                                }
                                            }

                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Check Payout Status Api</h5>                                        
                    </div>
                    <div class="m-t-30">
                        <div class="table-responsive-md table-responsive-sm">
                            <table class="table table-hover table-bordered" id="datatable"> 
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <td>https://api.zipmartnow.com/api/new/checkstatus</td>
                                    </tr>
                                    <tr>
                                        <th>Method</th>
                                        <td>POST</td>
                                    </tr>
                                    <tr>
                                        <th>Header</th>
                                        <td>Authorization: 91ed*************18e</td>
                                        <td>
                                            Here Your Authorization Key <a target="_blank" href="/user/dev-setting">click</a>
                                            <div>Pass Authorization Token in Authorization key.</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Request>
                                        <td>
                                            <div>referenceNumber: 31************55</div>
                                        </td>
                                        <td>Pass Order ID in referenceNumber key.</td>
                                    </tr>
                                    <tr>
                                        <th>Response</th>
                                        <td>
                                            <div>status: Success</div>
                                            <div>message: Transaction is Success</div>
                                            <div>data:{ payout_ref:31********55, TxnId:SEOS182*******85, bank_ref:325********05 }</div>
                                        </td>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Generate Bearer Token Api</h5>                                        
                    </div>
                    <div class="m-t-30">
                        <div class="table-responsive-md table-responsive-sm">
                            <table class="table table-hover table-bordered" id="datatable"> 
                                <thead>
                                    <tr>
                                        <th>URL</th>
                                        <td>https://api.zipmartnow.com/api/new/generateToken</td>
                                    </tr>
                                    <tr>
                                        <th>Method</th>
                                        <td>POST</td>
                                    </tr>
                                    <tr>
                                        <th>Header</th>
                                        <td>
                                            <div>AuthKey: O2a******e81</div>
                                            <div>AuthToken: 91ed*************18e</div>
                                        </td>
                                        <td>Here Your Authorization key <a target="_blank" href="/user/dev-setting">click</a></td>
                                    </tr>
                                    <tr>
                                        <th>Request</th>
                                        <td>
                                            <div>email: ab*****@gmail.com</div>
                                            <div>password: ab***3d</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Response</th>
                                        <td>
                                            <div>"status": true</div>
                                            <div>"message": "Bearer token generated***************days."</div>
                                            <div>"token": "eyJ0eXasd3j334j**********************************jzserwe3432"</div>
                                        </td>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Webhook/Callback Api</h5>                                        
                    </div>
                    <div class="m-t-30">
                        <div class="table-responsive-md table-responsive-sm">
                            <table class="table table-hover table-bordered" id="datatable"> 
                                <thead>
                                    @php($userData = auth()->user())
                                    <tr>
                                        <th>Payout Callback URL</th>
                                        @if(!$userData->payout_callback==null)
                                            <td>{{$userData->payout_callback}}</td>
                                        @else
                                            <td class="text-center">Not set.</td>
                                        @endif
                                    </tr>
                                    <tr>
                                        <th>Payin Callback URL</th>
                                        @if(!$userData->payin_callback==null)
                                            <td>{{$userData->payin_callback}}</td>
                                        @else
                                            <td class="text-center">Not set.</td>
                                        @endif
                                    </tr>
                                    
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>
<!-- Content Wrapper END -->
<!-- model -->        
@include('user/footer')