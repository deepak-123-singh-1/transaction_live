@include('user/header')

<div class="page-container">

    <!-- Content Wrapper START -->

    <div class="main-content">

        <div class="page-header">

            <h2 class="header-title">Payin</h2>

            <div class="header-sub-title">

                <nav class="breadcrumb breadcrumb-dash">

                    <a href="{{url('/user/dashboard')}}" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>                    

                    <span class="breadcrumb-item active">Payin</span>

                </nav>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="form-row">
                    <div class="col-md-4 mb-3">
                        <label for="">Amount</label>
                        <input type="text" class="form-control is-valid1" value="" name="amount" id="amount">                       
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="">Type</label>
                        <input type="text" class="form-control is-invalid1" value="INTENT" readonly>                        
                    </div>
                    <div class="col-md-4 mb-3">
                        <button type="button" class="btn btn-primary" onClick="generateLink();" style="margin-top: 28px;">Submit</button>                 
                    </div> 
                    
                    <div class="col-md-4 mb-3">
                    <a id="showIntant" style="display:none" class="btn btn-success" href="">DOPAYMENT</a>                
                    </div> 
                    <p id="showIntentLink"></p>
            </div>
        </div>
    </div>
</div>
<script>    
    function generateLink(){
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': csrfToken
            }
        });
        var amount = $("#amount").val();
        if(amount < 1){
            alert("Invalid amount");
            return false;
        }
        var url = '{{url('/user/generate-link')}}';
        $.ajax({
            type: 'POST',
            url: url,
            data: {
                'amount':amount,
            },
            success: function (response) {
               
               if(response == "Please try after some time")
               {
                    alert(response);
                    return false;
               }else{
                    $("#showIntentLink").empty();
                    $("a").attr("href",response);
                    $("#showIntant").show();
                    $("#showIntentLink").append(response);
               }
            }
        });
    }
</script>

@include('user/footer')