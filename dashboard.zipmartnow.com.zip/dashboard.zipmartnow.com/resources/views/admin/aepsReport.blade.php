@include('admin/header')

<div class="page-container">

    <!-- Content Wrapper START -->

    <div class="main-content">
        <div class="page-header">
            <h2 class="header-title">AEPS Report</h2>
            <div class="header-sub-title">
                <nav class="breadcrumb breadcrumb-dash">
                    <a href="{{url('/admin/dashboard')}}" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>                    
                    <span class="breadcrumb-item active">AEPS Report</span>
                </nav>
            </div>
        </div>

        <div class="card">
            <img src="{{ asset('public/assets/images/others/pageNotFound.jpg') }}" class="img-thumbnail" alt="image" style="height:400px">
        </div>
    </div>
</div>
@include('admin/footer')