<!-- Footer START -->

<footer class="footer">

    <div class="footer-content">

        <p class="m-b-0">Copyright © 2025 Admin Panel All rights reserved.</p>

        <span>

            <a href="#" class="text-gray m-r-15">Term &amp; Conditions</a>

            <a href="#" class="text-gray">Privacy &amp; Policy</a>

        </span>

    </div>

</footer>


<!-- Core Vendors JS -->

<script src="{{ asset('public/assets/js/vendors.min.js') }}"></script>



<script src="{{ asset('public/assets/js/pages/dashboard-default.js') }}"></script>

<script src="{{ asset('public/assets/js/dataTables.bootstrap.min.js') }}"></script>

{{-- <script src="{{ asset('public/assets/js/jquery.dataTables.min.js') }}"></script> --}}

{{-- <script src="{{ asset('public/assets/js/pages/datatables.js') }}"></script> --}}

<!-- Core JS -->

<script src="{{ asset('public/assets/js/app.min.js') }}"></script>

</body>

</html>