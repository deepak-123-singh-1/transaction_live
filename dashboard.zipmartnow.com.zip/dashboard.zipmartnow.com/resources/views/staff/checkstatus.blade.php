@include('staff/header')
<!-- Page Container START -->
<div class="page-container">
    <!-- Content Wrapper START -->
    <div class="main-content"> 
        <div class="row">
                <div class="col-lg-12">
                    <div class="horizontal-form">
                        <form action="{{ url('/staff/check-pending-status') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row">
                                <div class="col-md-6 mb-6">
                                    <input id="date" type="date" class="form-control" name="txndate" value="">
                                </div>

                                <div class="col-md-2  mb-2">
                                    <div class="form-group text-left">
                                        <button type="submit" class="btn btn-md btn-primary" name="submit" value="EXPORT">Run Crone</button>
                                    </div>                                        
                                </div>                                    
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        
    </div>
    <!-- Content Wrapper END -->
    <!-- model -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.1.1/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.1.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.html5.min.js"></script>
    

<script type="text/javascript">
    $(document).ready(function () {
        let dataTable = new DataTable('#datatable', {
            ordering: false,
            dom: 'Bfrtip',
            buttons: [
                'csv', 'excel', 'pdf'
            ]
        });
    });
</script>

@include('staff/footer')