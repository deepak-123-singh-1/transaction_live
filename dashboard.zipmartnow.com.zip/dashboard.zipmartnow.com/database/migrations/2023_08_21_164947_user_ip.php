<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_ipaddress', function (Blueprint $table) {
            $table->id();
            $table->integer('userId');          
            $table->text('ipAddress')->nullable();           
            $table->integer('created_by')->payin_callback();
            $table->integer('updated_by')->payout_callback();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_ipaddress');
    }
};
