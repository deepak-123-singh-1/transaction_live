<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayinModel extends Model
{
    use HasFactory;
    protected $table = 'payin_transactions';

    protected $fillable = [
        'userId',
        'txnId',               
        'orderId',
        'contactId',
        'amount',
        'charge',   
        'gst',           
        'totalAmount',
        'payerName',
        'payerMobile',
        'payerVa',
        'utr',
        'status',
        'IpAddress',
    ];
}

