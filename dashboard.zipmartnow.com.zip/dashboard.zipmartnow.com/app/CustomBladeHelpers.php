<?php

if (!function_exists('customHelper')) {
    function customHelper($param1, $param2) {
        // Your custom logic here
        return "Result: {$param1}, {$param2}";
    }
}
