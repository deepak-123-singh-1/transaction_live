<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PayoutIserveU;
use App\Http\Controllers\PayoutVouch;
use App\Http\Controllers\CallbackIserveU;
use App\Http\Controllers\CallbackVouch;
use App\Http\Controllers\CheckStatusIserveU;
use App\Http\Controllers\CheckStatusIserveUNew;
use App\Http\Controllers\CheckStatusVouch;
use App\Http\Controllers\PayintIserveU;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

//Route::post('v1/doPayout', [PayoutIserveU::class, 'doPayout']);
// Route::post('v2/callback/IserveU', [CallbackIserveU::class, 'callBackData']);
// Route::post('v1/checkstatus', [CheckStatusIserveU::class, 'checkStatus']);
// Route::post('v1/checkuserbalance', [CheckStatusIserveU::class, 'getUserBalance']);

//Route::post('v2/doPayout', [PayoutVouch::class, 'doPayout']);
// Route::post('v3/callback/Vouch', [CallbackVouch::class, 'callBackData']);
// Route::post('v3/callback/register', [CallbackVouch::class, 'registerCallBackUrl']);
// Route::post('v3/callback/Vouch-test', [CallbackVouch::class, 'testCallback']);

// Route::post('v2/checkstatus', [CheckStatusVouch::class, 'checkStatus']);

// Route::post('v1/genartePaymentLink', [PayintIserveU::class, 'genratePaymentLink']);
// Route::post('v1/new/checkstatus', [CheckStatusIserveUNew::class, 'checkStatus']);



